package com.agritech.cadastro.talhao;

public class CadTalhao {
	public CadTalhao(){
		System.out.println("Criou um CadTalhao");
 }   
}