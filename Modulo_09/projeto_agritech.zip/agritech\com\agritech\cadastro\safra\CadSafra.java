package com.agritech.cadastro.safra;

public class CadSafra {
	public CadSafra(){
		System.out.println("Criou um CadSafra");
 }
}