package com.agritech.cadastro;

import com.agritech.cadastro.fornecedor.CadFornecedor;
import com.agritech.cadastro.produto.CadProduto;
import com.agritech.cadastro.talhao.CadTalhao;
import com.agritech.cadastro.safra.CadSafra;
import com.agritech.cadastro.maquinario.CadMaquinario;
import com.agritech.cadastro.funcionario.CadFuncionario;

public class Main {
    public static void main(String args[]) {
	CadFornecedor cadastroFornecedor = new CadFornecedor();
	CadFuncionario cadastroFuncionario = new CadFuncionario();
	CadProduto cadastroProduto = new CadProduto();
	CadTalhao cadastroTalhao = new CadTalhao();
	CadSafra cadastroSafra = new CadSafra();
	CadMaquinario cadastroMaquinario = new CadMaquinario();        
	System.out.println("Executou Main.");
    }
}